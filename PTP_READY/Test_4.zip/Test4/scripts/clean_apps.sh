#!/bin/bash

for dir in apps/*/; do 
    rm "$dir"/*.exe
done
exit 0