#!/bin/bash

for src in expr_best expr_rand index_best index_rand ptr_best ptr_rand; do
    NMAX=1
    while [ $NMAX -le 10000 ]; do
        echo -n -e "$src O0 NMAX=$NMAX ... \r"
        gcc -DNMAX=$NMAX -O0 -o apps/${src}_O0/$NMAX.exe src/${src}.c
        echo -n -e "$src O2 NMAX=$NMAX ... \r"
        gcc -DNMAX=$NMAX -O2 -o apps/${src}_O2/$NMAX.exe src/${src}.c
        if [ $NMAX -eq 1 ]; then
            NMAX=0
        fi
        NMAX=$((NMAX + 500))
    done
done
exit 0