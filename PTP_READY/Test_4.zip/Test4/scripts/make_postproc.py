import matplotlib.pyplot as plt
import numpy as np

N = np.array([1, 500, 1000, 1500, 2000, 2500, 3000, 3500, 4000,
              4500, 5000, 5500, 6000, 6500, 7000, 7500, 8000, 8500, 9000, 9500, 10000])

def build_errors_plot():
    progs = ["expr_best_O2", "index_best_O2", "ptr_best_O2", "expr_rand_O2", "index_rand_O2", "ptr_rand_O2"]
    labels = ["*(a + i), O2, отсортирован", "a[i], O2, отсортирован", "*ptr, O2, отсортирован",
               "*(a + i), O2, неотсортирован", "a[i], O2, неотсортирован", "*ptr, O2, неотсортирован"]
    
    data = {prog: ([], [], [], []) for prog in progs}

    plt.figure(figsize=(20, 10))

    for prog in progs:
        with open(f"data/{prog}/data_errors.txt", "r") as file:
            while True:
                line = tuple(map(float, file.readline().strip().split()))
                if line == ():
                    break
                data[prog][0].append(line[0])
                data[prog][1].append(line[1])
                data[prog][2].append(line[2])
                data[prog][3].append(line[3])

    plt.figure(figsize=(20, 10))
    for index, prog in enumerate(progs):
        plt.plot(data[prog][0], data[prog][1], label=labels[index], alpha=1, linewidth=1)
    plt.title("Ошибка минимального значения")
    plt.xlabel("Количество элементов массива")
    plt.ylabel("Ошибка, мкс")
    plt.legend()
    plt.grid()
    plt.savefig("plots/plot3.svg")

    plt.figure(figsize=(20, 10))
    for index, prog in enumerate(progs):
        plt.plot(data[prog][0], data[prog][2], label=labels[index], alpha=1, linewidth=1)
    plt.title("Ошибка среднего значения")
    plt.xlabel("Количество элементов массива")
    plt.ylabel("Ошибка, мкс")
    plt.legend()
    plt.grid()
    plt.savefig("plots/plot4.svg")

    plt.figure(figsize=(20, 10))
    for index, prog in enumerate(progs):
        plt.plot(data[prog][0], data[prog][3], label=labels[index], alpha=1, linewidth=1)
    plt.title("Ошибка максимального значения")
    plt.xlabel("Количество элементов массива")
    plt.ylabel("Ошибка, мкс")
    plt.legend()
    plt.grid()
    plt.savefig("plots/plot5.svg")

def build_best_plot():
    progs = ["expr_best_O0", "index_best_O0", "ptr_best_O0", "expr_best_O2", "index_best_O2", "ptr_best_O2"]
    labels = ["*(a + i), O0", "a[i], O0", "*ptr, O0", "*(a + i), O2", "a[i], O2", "*ptr, O2"]
    
    data = {prog: ([], []) for prog in progs}

    plt.figure(figsize=(20, 10))
    for index, prog in enumerate(progs):
        with open(f"data/{prog}/data_means.txt", "r") as file:
            while True:
                line = tuple(map(float, file.readline().strip().split()))
                if line == ():
                    break
                data[prog][0].append(line[0])
                data[prog][1].append(line[1])
        plt.plot(data[prog][0], data[prog][1], label=labels[index], alpha=0.8, linewidth=1.2)

    plt.title("Зависимость времени сортировки массива выбором от числа элементов массива в случае, когда массив отсортирован")
    plt.xlabel("Количество элементов массива")
    plt.ylabel("Время выполнения (мкс)")
    plt.xticks(N)
    plt.yticks(np.linspace(plt.yticks()[0][1], plt.yticks()[0][-2], 9))
    plt.legend()
    plt.grid()
    plt.savefig("plots/plot1.svg")


def build_rand_plot():
    progs = ["expr_rand_O0", "index_rand_O0", "ptr_rand_O0", "expr_rand_O2", "index_rand_O2", "ptr_rand_O2"]
    labels = ["*(a + i), O0", "a[i], O0", "*ptr, O0", "*(a + i), O2", "a[i], O2", "*ptr, O2"]
    
    data = {prog: ([], []) for prog in progs}

    plt.figure(figsize=(20, 10))
    for index, prog in enumerate(progs):
        with open(f"data/{prog}/data_means.txt", "r") as file:
            while True:
                line = tuple(map(float, file.readline().strip().split()))
                if line == ():
                    break
                data[prog][0].append(line[0])
                data[prog][1].append(line[1])
        plt.plot(data[prog][0], data[prog][1], label=labels[index], alpha=0.8, linewidth=1.2)

    plt.title("Зависимость времени сортировки массива выбором от числа элементов массива в случае, когда массив неотсортирован")
    plt.xlabel("Количество элементов массива")
    plt.ylabel("Время выполнения (мкс)")
    plt.xticks(N)
    plt.yticks(np.linspace(plt.yticks()[0][1], plt.yticks()[0][-2], 9))
    plt.legend()
    plt.grid()
    plt.savefig("plots/plot2.svg")

def build_moustache_plot():
    labels = ["Отсортированный массив", "Неотсортированный массив"]
    
    data = {prog: ([], []) for prog in ["index_best_O2", "index_rand_O2"]}

    plt.figure(figsize=(20, 10))
    for index, prog in enumerate(["index_best_O2", "index_rand_O2"]):
        with open(f"data/{prog}/data_list.txt", "r") as file:
            while True:
                line = tuple(map(float, file.readline().strip().split()))
                if line == ():
                    break
                data[prog][0].append(line[0])
                data[prog][1].append([])
                for i in range(1, len(line)):
                    data[prog][1][-1].append(line[i])

        plt.plot(data[prog][0], tuple(map(np.median, data[prog][1])), label=labels[index], alpha=0.8, linewidth=1.2)
        plt.boxplot(data[prog][1], positions=data[prog][0], widths=100, showfliers=False)
    
    plt.title("График с усами для варианта обработки «через квадратные скобки» при уровне оптимизации O2.")
    plt.xlabel("Количество элементов массива")
    plt.ylabel("Время выполнения (мкс)")
    plt.legend()
    plt.grid()
    plt.savefig("plots/plot6.svg")


if __name__ == "__main__":
    build_best_plot()
    build_rand_plot()
    build_errors_plot()
    build_moustache_plot()

