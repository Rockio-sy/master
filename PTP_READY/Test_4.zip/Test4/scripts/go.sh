#!/bin/bash

scripts/build_apps.sh
scripts/update_data.sh
scripts/make_preproc.sh
scripts/make_postproc.sh
exit 0
