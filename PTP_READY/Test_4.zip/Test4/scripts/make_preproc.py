import numpy as np

progs = [
    "expr_best_O0", "expr_best_O2", "index_best_O0", "index_best_O2", "ptr_best_O0", "ptr_best_O2",
    "expr_rand_O0", "expr_rand_O2", "index_rand_O0", "index_rand_O2", "ptr_rand_O0", "ptr_rand_O2"
]

N = (
    1, 500, 1000, 1500, 2000, 2500, 3000, 3500, 4000, 4500, 5000, 5500, 6000, 6500,
    7000, 7500, 8000, 8500, 9000, 9500, 10000
)

for prog in progs:
    means = np.zeros(len(N))
    mins = np.full(len(N), np.inf)
    maxs = np.full(len(N), -np.inf)
    elems = [[] for _ in range(len(N))]

    with open(f"data/{prog}/data.txt", "r") as file:
        while True:
            line = tuple(map(int, file.readline().strip().split()))
            if line == ():
                break
            index = N.index(line[0])
            elems[index].append(line[1])
            means[index] += line[1]
            mins[index] = min(mins[index], line[1])
            maxs[index] = max(maxs[index], line[1])

    ns = np.zeros(len(N), dtype=int)
    for index, elem in enumerate(means):
        ns[index] = np.count_nonzero(np.array(elems[index]))
        if ns[index] != 0:
            means[index] /= ns[index]

    sums = np.zeros((len(N), 3))
    with open(f"data/{prog}/data.txt", "r") as file:
        while True:
            line = tuple(map(int, file.readline().strip().split()))
            if line == ():
                break
            index = N.index(line[0])
            sums[index][0] += (line[1] - mins[index]) ** 2
            sums[index][1] += (line[1] - means[index]) ** 2
            sums[index][2] += (line[1] - maxs[index]) ** 2

    with open(f"data/{prog}/data_means.txt", "w") as file:
        for index, elem in enumerate(N):
            file.write(f"{elem} {means[index]}\n")

    with open(f"data/{prog}/data_errors.txt", "w") as file:
        for index, elem in enumerate(N):
            if ns[index] != 0 and ns[index] > 1:
                value1 = np.sqrt(sums[index][0] / (ns[index] * (ns[index] - 1)))
                value2 = np.sqrt(sums[index][1] / (ns[index] * (ns[index] - 1)))
                value3 = np.sqrt(sums[index][2] / (ns[index] * (ns[index] - 1)))
            else:
                value1 = 0.0
                value2 = 0.0
                value3 = 0.0
            file.write(f"{elem} {value1} {value2} {value3}\n")

    with open(f"data/{prog}/data_list.txt", "w") as file:
        for index, elem in enumerate(N):
            file.write(f"{elem}")
            for i in elems[index]:
                file.write(f" {i}")
            file.write("\n")
