#!/bin/bash

for src in expr_best expr_rand index_best index_rand ptr_best ptr_rand; do
    for exe in apps/"${src}"_O0/*.exe; do
        echo -n -e "$src O0 ...\r"
        $exe >> data/"${src}"_O0/data.txt
    done
    for exe in apps/"${src}"_O2/*.exe; do
        echo -n -e "$src O2 ...\r"
        $exe >> data/"${src}"_O2/data.txt
    done
done
exit 0