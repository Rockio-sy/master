#!/bin/bash

for dir in data/*/; do 
    rm "$dir"/*.txt
done
exit 0