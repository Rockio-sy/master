#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <sys/time.h>
#include <time.h>

#ifndef NMAX
#error NMAX NOT DEFINED
#endif

unsigned long long microseconds_now(void)
{
    struct timeval val;

    if (gettimeofday(&val, NULL))
        return (unsigned long long) -1;

    return val.tv_sec * 1000000ULL + val.tv_usec;
}

void insertion_sort(int *pbeg, int *pend)
{
    for (int *pi = pbeg + 1; pi < pend; pi++)
        for (int *pk = pi; pk > pbeg && *pk < *(pk - 1); pk--)
        {
            int tmp = *pk;
            *pk = *(pk - 1);
            *(pk - 1) = tmp;
        }
}

int main(void)
{
    int arr[NMAX];
    size_t len = NMAX;
    srand(time(NULL));
    for (size_t i = 0; i < NMAX; i++)
        arr[i] = rand();

    unsigned long long beg = microseconds_now();
    insertion_sort(arr, arr + len);
    unsigned long long end = microseconds_now();

    printf("%d %llu\n", NMAX, end - beg);

    return EXIT_SUCCESS;
}
