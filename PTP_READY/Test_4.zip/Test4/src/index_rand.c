#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <sys/time.h>
#include <time.h>

#ifndef NMAX
#error NMAX NOT DEFINED
#endif

unsigned long long microseconds_now(void)
{
    struct timeval val;

    if (gettimeofday(&val, NULL))
        return (unsigned long long) -1;

    return val.tv_sec * 1000000ULL + val.tv_usec;
}

void insertion_sort(int arr[], size_t len)
{
    for (size_t i = 1; i < len; i++)
        for (size_t k = i; k > 0 && arr[k] < arr[k - 1]; k--)
        {
            int tmp = arr[k];
            arr[k] = arr[k - 1];
            arr[k - 1] = tmp;
        }
}

int main(void)
{
    int arr[NMAX];
    size_t len = NMAX;
    srand(time(NULL));
    for (size_t i = 0; i < NMAX; i++)
        arr[i] = rand();

    unsigned long long beg = microseconds_now();
    insertion_sort(arr, len);
    unsigned long long end = microseconds_now();

    printf("%d %llu\n", NMAX, end - beg);

    return EXIT_SUCCESS;
}
