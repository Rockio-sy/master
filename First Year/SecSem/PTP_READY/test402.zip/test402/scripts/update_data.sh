#!/bin/bash

if [ $# -lt 1 ]; then
    n=1
else
    n=$1
fi

count=0
while [ $count -lt "$n" ]; do
    for src in notranspose transpose; do
        for exe in apps/"${src}"_O0/*.exe; do
            echo -n -e "$src O0 ...\r"
            $exe >> data/"${src}"_O0/data.txt
        done
        for exe in apps/"${src}"_O3/*.exe; do
            echo -n -e "$src O3 ...\r"
            $exe >> data/"${src}"_O3/data.txt
        done
        for exe in apps/"${src}"_Os/*.exe; do
            echo -n -e "$src Os ...\r"
            $exe >> data/"${src}"_Os/data.txt
        done
    done
    count=$((count+1))
done
exit 0