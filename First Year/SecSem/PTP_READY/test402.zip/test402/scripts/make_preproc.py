import numpy as np

def calculate_stats(data):
    n = len(data)
    mean = np.mean(data)
    std_dev = np.std(data)
    return mean, std_dev

def calculate_quartiles(data):
    return np.percentile(data, [25, 50, 75])

def process_data(prog, N):
    means = []
    mins = []
    maxs = []
    elems = []
    quartiles = []

    with open(f"data/{prog}/data.txt", "r") as file:
        for _ in range(len(N)):
            elems.append([])
            quartiles.append([None, None, None])

        for line in file:
            values = list(map(int, line.strip().split()))
            index = N.index(values[0])
            elems[index].append(values[1])

    for data in elems:
        mean, std_dev = calculate_stats(data)
        means.append(mean)
        mins.append(np.min(data))
        maxs.append(np.max(data))

    with open(f"data/{prog}/data_means.txt", "w") as file:
        for elem in zip(N, means):
            file.write(f"{elem[0]} {elem[1]}\n")

    with open(f"data/{prog}/data_errors.txt", "w") as file:
        for index, elem in enumerate(zip(N, means)):
            n = len(elems[index])
            if n > 1:
                std_error = std_dev / np.sqrt(n * (n - 1))
            else:
                std_error = 0.0
            file.write(f"{elem[0]} {std_error} {std_error} {std_error}\n")

    with open(f"data/{prog}/data_list.txt", "w") as file:
        for index, elem in enumerate(zip(N, elems)):
            file.write(f"{elem[0]} {' '.join(map(str, elem[1]))}\n")

    with open(f"data/{prog}/data_list.txt", "r") as file:
        with open(f"data/{prog}/data_quartiles.txt", "w") as fileout:
            for line in file:
                values = list(map(int, line.strip().split()))
                fileout.write(f"{values[0]} {' '.join(map(str, calculate_quartiles(values[1:])))}\n")

if __name__ == "__main__":
    progs = ["notranspose_O0", "notranspose_O3", "notranspose_Os",
             "transpose_O0", "transpose_O3", "transpose_Os"]
    N = [1] + list(range(10, 1001, 10))

    for prog in progs:
        process_data(prog, N)

