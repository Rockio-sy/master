#!/bin/bash

if [ $# -lt 1 ]; then
    n=1
else
    n=$1
fi

scripts/build_apps.sh
scripts/update_data.sh "$n"
python3 scripts/make_preproc.py
python3 scripts/make_postproc.py
exit 0