#!/bin/bash

mkdir apps 2> /dev/null
mkdir data 2> /dev/null

STEP=10
MAX=1000

for src in notranspose transpose; do
    mkdir apps/${src}_O0/ 2> /dev/null
    mkdir apps/${src}_O3/ 2> /dev/null
    mkdir apps/${src}_Os/ 2> /dev/null
    mkdir data/${src}_O0/ 2> /dev/null
    mkdir data/${src}_O3/ 2> /dev/null
    mkdir data/${src}_Os/ 2> /dev/null
    N=1
    while [ $N -le $MAX ]; do
        echo -n -e "$src O0 N=$N ... \r"
        gcc -std=c99 -DN=$N -O0 -o apps/${src}_O0/$N.exe src/${src}.c
        echo -n -e "$src O3 N=$N ... \r"
        gcc -std=c99 -DN=$N -O3 -o apps/${src}_O3/$N.exe src/${src}.c
        echo -n -e "$src Os N=$N ... \r"
        gcc -std=c99 -DN=$N -Os -o apps/${src}_Os/$N.exe src/${src}.c
        if [ $N -eq 1 ]; then
            N=0
        fi
        N=$((N + STEP))
    done
done
exit 0