import matplotlib.pyplot as plt
import numpy as np

def read_data_means(prog):
    data = ([], [])
    with open(f"data/{prog}/data_means.txt", "r") as file:
        for line in file:
            values = list(map(float, line.strip().split()))
            data[0].append(values[0])
            data[1].append(values[1])
    return data

def plot_data(progs, labels, filename):
    plt.figure(figsize=(20, 10))
    for index, prog in enumerate(progs):
        data = read_data_means(prog)
        plt.plot(data[0], data[1], label=labels[index], alpha=0.8, linewidth=1.2)

    plt.title("Matrix Multiplication Time Dependency on Matrix Dimension with or without Right Matrix Transposition")
    plt.xlabel("Matrix Dimension")
    plt.ylabel("Execution Time (μs)")
    plt.legend()
    plt.grid()
    plt.savefig(filename)

if __name__ == "__main__":
    N = [1] + list(range(10, 1001, 10))
    progs = ["notranspose_O0", "notranspose_O3", "notranspose_Os",
             "transpose_O0", "transpose_O3", "transpose_Os"]
    labels = ("Without Transposition, O0", "Without Transposition, O3",
              "Without Transposition, Os", "With Transposition, O0", "With Transposition, O3", "With Transposition, Os")
    plot_data(progs, labels, "plots/plot.svg")

