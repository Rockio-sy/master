#include <stdio.h>
#include <time.h>
#include <sys/time.h>

#ifndef N
#error N NOT DEFINED
#endif

typedef int matrix_t[N][N];

matrix_t matrix_1, matrix_2, matrix_3;

unsigned long long microseconds_now(void)
{
    struct timeval val;

    if (gettimeofday(&val, NULL))
        return (unsigned long long) -1;

    return val.tv_sec * 1000000ULL + val.tv_usec;
}

void matrix_multiply(matrix_t dst, matrix_t matrix_1, matrix_t matrix_2)
{
    for (size_t i = 0; i < N; i++)
        for (size_t j = 0; j < N; j++)
        {
            dst[i][j] = 0;
            for (size_t k = 0; k < N; k++)
                dst[i][j] += matrix_1[i][k] * matrix_2[k][j];
        }
}

int main(void)
{
    unsigned long long beg, end;

    for (int i = 0; i < N * N; i++)
    {   
        matrix_1[i / N][i % N] = i + 1;
        matrix_2[i / N][i % N] = i + 3;
    }

    beg = microseconds_now();
    matrix_multiply(matrix_3, matrix_1, matrix_2);
    end = microseconds_now();
    
    printf("%d %llu\n", N, end - beg);
}

